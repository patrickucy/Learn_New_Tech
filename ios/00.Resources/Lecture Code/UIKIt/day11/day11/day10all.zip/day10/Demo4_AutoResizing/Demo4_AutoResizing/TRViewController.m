//
//  TRViewController.m
//  Demo4_AutoResizing
//
//  Created by apple on 13-6-18.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()

@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    CGRect frame = CGRectZero;
    frame.size.width = 80;
    frame.size.height = 20;
    frame.origin.y = 10;
    frame.origin.x = self.view.bounds.size.width - 10 - frame.size.width;
    
    UILabel * label = [[UILabel alloc] initWithFrame:frame];
    label.text = @"text";
    label.textAlignment = NSTextAlignmentRight;
    label.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleBottomMargin;
    [self.view addSubview:label];
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 60, 300, self.view.bounds.size.height - 120)];
    imageView.image = [UIImage imageNamed:@"Elephant.jpg"];
    imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    [self.view addSubview:imageView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
