//
//  TRGroup.m
//  Demo_CoreData
//
//  Created by apple on 13-7-2.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "TRGroup.h"
#import "TRContact.h"


@implementation TRGroup

@dynamic name;
@dynamic contacts;

@end
