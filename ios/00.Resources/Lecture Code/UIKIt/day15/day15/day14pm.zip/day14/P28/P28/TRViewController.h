//
//  TRViewController.h
//  P28
//
//  Created by apple on 13-6-24.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
