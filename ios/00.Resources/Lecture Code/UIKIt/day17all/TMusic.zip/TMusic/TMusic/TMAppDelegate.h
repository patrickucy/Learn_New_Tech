//
//  TMAppDelegate.h
//  TMusic
//
//  Created by 赵 哲 on 13-6-25.
//  Copyright (c) 2013年 Zhe Zhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
