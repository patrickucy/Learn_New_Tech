//
//  TRWeiboLoadingView.h
//  Demo3_WeiboLoading
//
//  Created by apple on 13-6-20.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRWeiboLoadingView : UIView

@property (nonatomic) float value; // 0.0 - 1.0

@end
