//
//  TRViewController.m
//  Demo3_Layout
//
//  Created by apple on 13-6-18.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "TRViewController.h"

@interface TRViewController ()

@end

@implementation TRViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillLayoutSubviews
{
    //布局1:用代码布局
    NSLog(@"%.2f, %.2f", self.view.bounds.size.width,
          self.view.bounds.size.height);
    
    CGRect frame = self.button.frame;
    frame.origin.x = 10;
    frame.origin.y = self.view.bounds.size.height - frame.size.height - 10;
    self.button.frame = frame;
    
    //P21
    //1. 保持在右下角 距离右下角各10p 按钮宽度不变
    CGRect rightBottomFrame = self.rightBottomButton.frame;
    rightBottomFrame.origin.x = self.view.bounds.size.width - 10 - rightBottomFrame.size.width;
    rightBottomFrame.origin.y = self.view.bounds.size.height
    - 10 - rightBottomFrame.size.height;
    self.rightBottomButton.frame = rightBottomFrame;
    
    //2. 保持在上方 距离上左右各10p 按钮宽度随屏幕宽度而变
    CGRect topFrame = self.topButton.frame;
    topFrame.origin = CGPointMake(10, 10);
    topFrame.size.width = self.view.bounds.size.width - 10 * 2;
    self.topButton.frame = topFrame;
    
    //3*.一个按钮保持在屏幕的右下方宽度60p距离右下角各10p
    //   另外一个按钮保持在刚才那个按钮的左边10p
    
    CGRect rightBottomFrame2 = self.rightBottomButton2.frame;
    rightBottomFrame2.origin.y = self.view.bounds.size.height - 10 - rightBottomFrame2.size.height;
//    rightBottomFrame2.origin.x = self.view.bounds.size.height - 10 - rightBottomFrame.size.width - 10 - rightBottomFrame2.size.width;
    rightBottomFrame2.origin.x = rightBottomFrame.origin.x - 10 - rightBottomFrame2.size.width;
    self.rightBottomButton2.frame = rightBottomFrame2;
    
    
    
    
    
    
    
    [super viewWillLayoutSubviews];
}

//iOS5.0之前声明支持屏幕方向 
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
//    return toInterfaceOrientation == UIInterfaceOrientationPortrait;
    return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

//iOS6.0之后覆盖下面方法并返回需要的屏幕方向
- (NSUInteger)supportedInterfaceOrientations
{
//    return UIInterfaceOrientationMaskPortrait;
    return UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskLandscapeLeft;
}




@end


/*
 int a = 12;                0000 1100
 int b = 9;                 0000 1001
 
 int c = a | b              0000 1101
 int d = a & b              0000 1000
 
 int e = a << 1             0001 1000
 int f = a >> 1             0000 0110
 
 1<<3                            1000   

 1                          0000 0001
 8                          0000 1000
                            0000 1001
 
 2                          0000 0010
 16                         0001 0000
 4                          0000 0100
 
 */
















