//
//  TRContact.h
//  Demo3_Contacts
//
//  Created by apple on 13-7-1.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRContact : NSObject

@property (copy, nonatomic) NSString * name;
@property (copy, nonatomic) NSString * age;
@property (copy, nonatomic) NSString * phoneNumber;

@end
