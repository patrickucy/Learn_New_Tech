//
//  TRSimpleAreaViewController.h
//  Demo1_PropertyList
//
//  Created by apple on 13-6-28.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRSimpleAreaViewController : UITableViewController

@property (nonatomic, strong) NSArray * areas;

@end
