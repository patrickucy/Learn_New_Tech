//
//  TRContact.m
//  Demo_CoreData
//
//  Created by apple on 13-7-2.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "TRContact.h"
#import "TRGroup.h"


@implementation TRContact

@dynamic name;
@dynamic age;
@dynamic phoneNumber;
@dynamic group;

@end
