//
//  main.m
//  TMusic
//
//  Created by 赵 哲 on 13-6-25.
//  Copyright (c) 2013年 Zhe Zhao. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TMAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TMAppDelegate class]));
    }
}
