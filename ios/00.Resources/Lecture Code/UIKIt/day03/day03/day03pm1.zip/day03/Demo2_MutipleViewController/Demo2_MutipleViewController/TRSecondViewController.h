//
//  TRSecondViewController.h
//  Demo2_MutipleViewController
//
//  Created by apple on 13-6-4.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRSecondViewController : UIViewController

@property (retain, nonatomic) IBOutlet UILabel *label;

@property (retain, nonatomic) NSString * bloodDescription;

@end
