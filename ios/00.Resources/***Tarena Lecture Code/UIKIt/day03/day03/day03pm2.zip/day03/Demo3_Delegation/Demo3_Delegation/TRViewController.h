//
//  TRViewController.h
//  Demo3_Delegation
//
//  Created by apple on 13-6-4.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRViewController : UIViewController
- (IBAction)chooseBlood:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *button;

@end
