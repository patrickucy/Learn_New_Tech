//
//  TRImageViewController.h
//  P10
//
//  Created by apple on 13-6-7.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRImageViewController : UIViewController

@property (retain, nonatomic) UIImage * image;

@end
