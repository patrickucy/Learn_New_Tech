//
//  TRViewController.h
//  Demo3_SC
//
//  Created by apple on 13-6-14.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRViewController : UIViewController

- (IBAction)tap:(UISegmentedControl *)sender;
@property (retain, nonatomic) IBOutlet UIWebView *webView;

@end
