//
//  TMStandardCell.h
//  TMusic
//
//  Created by 赵 哲 on 13-6-26.
//  Copyright (c) 2013年 Zhe Zhao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMStandardCell : UITableViewCell

@end
