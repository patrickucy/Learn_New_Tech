//
//  TRSong.h
//  Demo1_TableView_NibCell
//
//  Created by apple on 13-6-14.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRSong : NSObject

@property (copy, nonatomic) NSString * title;
@property (copy, nonatomic) NSString * singerName;
@property (copy, nonatomic) NSString * length;


@end
