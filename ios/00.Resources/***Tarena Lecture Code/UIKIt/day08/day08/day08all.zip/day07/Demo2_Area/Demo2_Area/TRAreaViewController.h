//
//  TRAreaViewController.h
//  Demo2_Area
//
//  Created by apple on 13-6-13.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRArea.h"

@interface TRAreaViewController : UITableViewController

@property (retain, nonatomic) TRArea * rootArea;

@end
