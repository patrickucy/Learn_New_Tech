//
//  TRAppDelegate.h
//  Demo4_TableView_DIY_Cell
//
//  Created by apple on 13-6-13.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TRViewController;

@interface TRAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TRViewController *viewController;

@end
