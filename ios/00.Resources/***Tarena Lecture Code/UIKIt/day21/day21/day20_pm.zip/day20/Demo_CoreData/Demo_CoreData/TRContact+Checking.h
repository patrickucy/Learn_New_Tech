//
//  TRContact+Checking.h
//  Demo_CoreData
//
//  Created by apple on 13-7-2.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import "TRContact.h"

@interface TRContact (Checking)

- (BOOL) isAdult;

@end
