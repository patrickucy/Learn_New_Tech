//
//  TRMessageView2.h
//  Demo1_BezierPath
//
//  Created by apple on 13-6-20.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRMessageView2 : UIView

@end
