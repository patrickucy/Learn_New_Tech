//
//  TRArea.h
//  Demo1_PropertyList
//
//  Created by apple on 13-6-28.
//  Copyright (c) 2013年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TRArea : NSObject

@property (copy,   nonatomic) NSString * areaName;
@property (strong, nonatomic) NSArray  * subAreas;

@end
